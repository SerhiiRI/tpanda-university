package com.company;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;


public class Main {

    public static ArrayList<String> history = new ArrayList<>();
    public static JFrame frame = new JFrame("Test frame");

    public static void createGUI() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        JPanel panelToScroll = new JPanel();
        JPanel panelSouth = new JPanel();
        JTextField text = new JTextField();
        final JScrollPane scrollPane = new JScrollPane(panelToScroll);

        mainPanel.setLayout(new BorderLayout());
        panelToScroll.setLayout(new BoxLayout(panelToScroll, BoxLayout.Y_AXIS));
        panelSouth.setLayout(new BoxLayout(panelSouth, BoxLayout.Y_AXIS));

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        text.setPreferredSize(new Dimension(150, 20));
        panelSouth.add(text);

        text.addActionListener(new BoxListener(text, panelToScroll));

        final JCheckBox checkBox1 = new JCheckBox("Show vertical scrollbar");
        checkBox1.setSelected(true);
        checkBox1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (checkBox1.isSelected()) {
                    scrollPane
                            .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
                } else {
                    scrollPane
                            .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
                }
            }
        });
        panelSouth.add(checkBox1);

        final JCheckBox checkBox2 = new JCheckBox("Show horizontal scrollbar");
        checkBox2.setSelected(true);
        checkBox2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (checkBox2.isSelected()) {
                    scrollPane
                            .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
                } else {
                    scrollPane
                            .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
                }
            }
        });
        panelSouth.add(checkBox2);

        mainPanel.add(panelSouth, BorderLayout.SOUTH);

        frame.getContentPane().add(mainPanel);
        frame.setPreferredSize(new Dimension(450, 500));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.repaint();
        frame.setVisible(true);
    }


    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame.setDefaultLookAndFeelDecorated(true);
                createGUI();
            }
        });
    }
}