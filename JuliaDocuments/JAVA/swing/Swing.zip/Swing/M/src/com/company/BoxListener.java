package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class BoxListener implements ActionListener {

    JTextField text;
    JPanel panelToScroll;

    BoxListener(JTextField text, JPanel panelToScroll) {
        this.text = text;
        this.panelToScroll = panelToScroll;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        Random random = new Random();
        if (!text.getText().equals("")) {
            createMessage(0);
            for (int i = 0; i < 3; i++) {
                if (random.nextInt(3) == i)
                    createMessage(1);
            }
            SwingUtilities.updateComponentTreeUI(Main.frame);
        } else
            System.out.println("Invalid input!");
    }

    public static int r = 1;
    public static int w = 14;

    public void createMessage(int n) {

        String str = "";
        str = calculate(str);

        JTextArea textArea = new JTextArea(r, w);

        JPanel panelText = new JPanel();
        panelText.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        panelText.setBackground(Color.gray);
        if (n == 0) {
            panelText.setLayout(new FlowLayout(FlowLayout.RIGHT));
            textArea.setBackground(Color.MAGENTA);
            textArea.setForeground(Color.WHITE);
            textArea.setText(str);
            Main.history.add(text.getText());
        } else {
            panelText.setLayout(new FlowLayout(FlowLayout.LEFT));
            textArea.setBackground(Color.cyan);
            textArea.setForeground(Color.DARK_GRAY);
            textArea.setText("Під лежачий дедлайн \n вода не тече!!!");
        }

        panelText.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        textArea.setHighlighter(null);
        textArea.setEditable(false);

        panelText.add(textArea);
        panelToScroll.add(panelText);

        text.setText("");
    }

    public String calculate(String str) {
        int number;
        number = text.getText().length() / w;
        r = r * number;
        char chars;
        for (int i = 0; i < text.getText().length(); i++) {
            chars = text.getText().charAt(i);
            str = str + chars;
            if (i % w == 0 && i != 0)
                str = str + "\n";
        }
        return str;
    }

}
