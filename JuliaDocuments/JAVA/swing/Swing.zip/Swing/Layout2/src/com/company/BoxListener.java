package com.company;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;

class BoxListener extends MouseAdapter {

    Color color;
    String oneChar;

    BoxListener(Color color, String oneChar) {
        this.color = color;
        this.oneChar = oneChar;
    }

    public void mouseClicked(MouseEvent me) {
        systemExit();
        NewFrame newFrame = new NewFrame();
        newFrame.runNewFrame(color, oneChar);
    }

    private void systemExit() {
        WindowEvent winCloseing = new WindowEvent(Main.frame, WindowEvent.WINDOW_CLOSING);
    }
}
