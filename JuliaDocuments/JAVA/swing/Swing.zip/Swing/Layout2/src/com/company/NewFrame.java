package com.company;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class NewFrame {
    public void runNewFrame(Color color, String oneChar) {

        JFrame new_frame = new JFrame();
        new_frame.setSize(1800, 1000);

        ResizeLabelFont jlabel = new ResizeLabelFont(oneChar);
        jlabel.setForeground(color);
        new_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        new_frame.getContentPane().add(jlabel);
        new_frame.setSize(1800, 1000);
        new_frame.setLocationRelativeTo(null);
        new_frame.setVisible(true);
    }
}

