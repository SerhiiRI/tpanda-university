package com.company;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

class RandomColorPanel {

    Random random = new Random();

    public JPanel generatePanel(JPanel mainPanel, JPanel panel1, JPanel panel2) {
        Dimension size = new Dimension(mainPanel.getWidth(), mainPanel.getHeight());

        if (size.getWidth() > size.getHeight()) {
            mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.X_AXIS));
            int w = calculateSize((int) size.getWidth());
            panel1.setPreferredSize(new Dimension(w, (int) size.getHeight()));
            panel2.setPreferredSize(new Dimension((int) size.getWidth() - w, (int) size.getHeight()));
            panel1.setSize(new Dimension(w, (int) size.getHeight()));
            panel2.setSize(new Dimension((int) size.getWidth() - w, (int) size.getHeight()));
        } else {
            mainPanel.setLayout((new BoxLayout(mainPanel, BoxLayout.Y_AXIS)));
            int h = calculateSize(size.getHeight());
            panel1.setPreferredSize((new Dimension((int) size.getWidth(), h)));
            panel2.setPreferredSize(new Dimension((int) size.getWidth(), (int) size.getHeight() - h));
            panel1.setSize((new Dimension((int) size.getWidth(), h)));
            panel2.setSize(new Dimension((int) size.getWidth(), (int) size.getHeight() - h));
        }
        Color color1 = randomColor();
        Color color2 = randomColor();
        panel1.setBackground(color1);
        panel2.setBackground(color2);
        String oneChar = String.valueOf(randomCharacter());
        JLabel jlabel = new JLabel(oneChar, JLabel.CENTER);
        jlabel.setFont(new Font("Tacoma", Font.BOLD, 14));
        jlabel.setForeground(Color.WHITE);
        panel1.add(jlabel);
        panel2.add(jlabel);
        panel1.addMouseListener(new BoxListener(color1, oneChar));
        panel2.addMouseListener(new BoxListener(color2, oneChar));
        mainPanel.add(panel1);
        mainPanel.add(panel2);
        return mainPanel;
    }

    public char randomCharacter() {
        return (char) ('a' + random.nextInt(26));
    }

    public Integer calculateSize(int value) {
        return (value / 4) * random.nextInt(4);
    }

    public Integer calculateSize(double value) {
        return ((int) value / 4) * random.nextInt(4);
    }

    public Color randomColor() {
        Color[] colors = {new Color(59, 141, 153), new Color(107, 107, 131), new Color(255, 175, 123), new Color(44, 83, 100), new Color(32, 58, 67), new Color(58, 28, 113), new Color(74, 197, 154), Color.BLACK, Color.DARK_GRAY, Color.CYAN, Color.MAGENTA};
        return colors[random.nextInt(colors.length)];
    }
}
