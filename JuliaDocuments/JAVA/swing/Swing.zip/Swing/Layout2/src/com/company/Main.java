package com.company;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static JFrame frame = new JFrame("Frame");

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createGUI();
            }
        });
    }

    public static void createGUI() {
        frame.setSize(1000, 800);
        JPanel mainPanel = new JPanel();
        mainPanel.setSize(new Dimension(frame.getWidth(), frame.getHeight()));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.X_AXIS));

        addPanels(mainPanel);

        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public static void addPanels(JPanel mainPanel) {

        JPanel panel1 = new JPanel();
        JPanel panel2 = new JPanel();
        JPanel panel11 = new JPanel();
        JPanel panel12 = new JPanel();
        JPanel panel21 = new JPanel();
        JPanel panel22 = new JPanel();
        JPanel panel111 = new JPanel();
        JPanel panel112 = new JPanel();
        JPanel panel121 = new JPanel();
        JPanel panel211 = new JPanel();
        JPanel panel212 = new JPanel();
        JPanel panel221 = new JPanel();
        JPanel panel222 = new JPanel();

        RandomColorPanel randomPanel = new RandomColorPanel();

        mainPanel = randomPanel.generatePanel(mainPanel, panel1, panel2);
        panel1 = randomPanel.generatePanel(panel1, panel11, panel12);
        panel2 = randomPanel.generatePanel(panel2, panel21, panel22);
        panel11 = randomPanel.generatePanel(panel11, panel111, panel112);
        panel12 = randomPanel.generatePanel(panel12, panel121, panel121);
        panel21 = randomPanel.generatePanel(panel21, panel211, panel212);
        panel22 = randomPanel.generatePanel(panel22, panel221, panel222);

        panel1.add(panel11);
        panel1.add(panel12);
        panel2.add(panel21);
        panel2.add(panel22);
        mainPanel.add(panel1);
        mainPanel.add(panel2);
    }

}


