package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

public class Main {

    public static int number = 0;

    public static void createGUI() {
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        JButton button1 = new JButton("+");
        JButton button2 = new JButton("-");
        JLabel label = new JLabel();

        button1.setText("+");
        button2.setText("-");

        label.setText(String.valueOf(number));
        label.setFont(new Font("Tacoma", Font.PLAIN, 28));

        label.setForeground(Color.WHITE);

        button1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                number++;
                label.setText(String.valueOf(number));
            }
        });

        button2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                number--;
                label.setText(String.valueOf(number));
            }
        });

        panel.setLayout(new GridLayout(1, 3, 20, 20));
        panel.add(button1);
        panel.add(label);
        panel.add(button2);

        panel.setBackground(Color.MAGENTA);
        frame.setSize(new Dimension(400, 400));

        frame.add(panel);
        frame.setVisible(true);

    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame.setDefaultLookAndFeelDecorated(true);
                createGUI();
            }
        });
    }
}
