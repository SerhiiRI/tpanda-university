package com.company;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void createGUI() {
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        panel.setBackground(Color.CYAN);
        JLabel label = new JLabel();
        label.setText("Hello world!!!!");
        label.setFont(new Font("Tacoma", Font.BOLD, 44));
        label.setForeground(Color.DARK_GRAY);
        label.setBorder(BorderFactory.createEmptyBorder(20, 200, 20, 20));
        panel.setLayout(new BorderLayout());
        panel.add(label, BorderLayout.CENTER);
        frame.add(panel);
        frame.setSize(new Dimension(800, 600));
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame.setDefaultLookAndFeelDecorated(true);
                createGUI();
            }
        });
    }
}
