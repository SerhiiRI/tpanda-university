package com.company;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicSplitPaneUI;
import java.awt.*;

public class Main {
    private static final Color color_up = new Color(44, 62, 80);
    private static final Color color_left = new Color(55, 121, 141);
    private static final Color color_right = new Color(76, 161, 175);

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createGUI();
            }
        });
    }

    public static void createGUI() {
        JFrame.setDefaultLookAndFeelDecorated(true);
        JFrame frame = new JFrame("Test frame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel left = new ColorPanel(color_left, 200, 600);
        left.setOpaque(true);
        JPanel right = new ColorPanel(color_right, 800, 600);
        right.setOpaque(true);

        JButton jButton1 = new JButton("Button 1");
        jButton1.setForeground(new Color(204, 204, 204));
        jButton1.setContentAreaFilled(false);

        JButton jButton2 = new JButton("Button 2");
        jButton2.setForeground(new Color(204, 204, 204));
        jButton2.setContentAreaFilled(false);

        JButton jButton3 = new JButton("Button 3");
        jButton3.setForeground(new Color(204, 204, 204));
        jButton3.setContentAreaFilled(false);

        JButton jButton4 = new JButton("Button 4");
        jButton4.setForeground(new Color(204, 204, 204));
        jButton4.setContentAreaFilled(false);

        JButton jButton5 = new JButton("Button 5");
        jButton5.setForeground(new Color(204, 204, 204));
        jButton5.setContentAreaFilled(false);

        JTextArea jt = new JTextArea(10, 5);
        jt.setPreferredSize(new Dimension(800, 740));

        String str = "Hello!";
        JButton jButton6 = new JButton(str);
        jButton6.setForeground(new Color(204, 204, 204));
        jButton6.setContentAreaFilled(false);
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jt.setText(str);
            }
        });

        right.setLayout(new FlowLayout());
        right.add(jButton6);
        right.add(jt);

        GridLayout layout_button = new GridLayout(5, 0);

        left.setLayout(layout_button);
        left.add(jButton1);
        left.add(jButton2);
        left.add(jButton3);
        left.add(jButton4);
        left.add(jButton5);

        JPanel content = new JPanel();
        content.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.FIRST_LINE_START;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 0.2;
        gbc.weighty = 1.0;
        gbc.gridx = 0;
        gbc.gridy = 0;

        content.add(left, gbc);
        gbc.weightx = 0.8;
        gbc.gridx = 1;
        content.add(right, gbc);

        frame.getContentPane().add(new ColorPanel(color_up, 1000, 80), BorderLayout.NORTH);
        frame.getContentPane().add(content);
        frame.pack();
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
    }

}

class ColorPanel extends JPanel {
    private int prefW;
    private int prefH;

    public ColorPanel(Color color, int prefW, int prefH) {
        setBackground(color);
        this.prefW = prefW;
        this.prefH = prefH;
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(prefW, prefH);
    }
}
