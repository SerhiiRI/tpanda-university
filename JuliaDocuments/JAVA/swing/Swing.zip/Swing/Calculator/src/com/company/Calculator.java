package com.company;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

class Calculator extends JFrame implements ActionListener {

    static JFrame f;

    static JTextField l;

    String s0, s1, s2;

    Calculator() {
        s0 = s1 = s2 = "";
    }

    public static void main(String args[]) {
        f = new JFrame("calculator");

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        Calculator c = new Calculator();

        l = new JTextField(20);

        l.setEditable(false);

        JButton b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, bv, bs, bk, bn, bf, bm, be, beq, beq1;

        b0 = new JButton("0");
        b1 = new JButton("1");
        b2 = new JButton("2");
        b3 = new JButton("3");
        b4 = new JButton("4");
        b5 = new JButton("5");
        b6 = new JButton("6");
        b7 = new JButton("7");
        b8 = new JButton("8");
        b9 = new JButton("9");

        beq1 = new JButton("=");

        bs = new JButton("+");
        bm = new JButton("-");
        bv = new JButton("V2");
        bk = new JButton("k2");
        bn = new JButton("kn");
        bf = new JButton("k!");
        beq = new JButton("C");

        be = new JButton(".");

        JPanel d = new JPanel();
        JPanel up = new JPanel();
        JPanel main = new JPanel();
        main.setLayout(new BorderLayout());
        main.add(up, BorderLayout.NORTH);
        main.add(d, BorderLayout.CENTER);
        up.setBackground(Color.gray);
        d.setBackground(Color.MAGENTA);
        d.setLayout(new GridLayout(5, 5, 8, 8));

        bf.addActionListener(c);
        bn.addActionListener(c);
        bm.addActionListener(c);
        bv.addActionListener(c);
        bs.addActionListener(c);
        bk.addActionListener(c);
        b9.addActionListener(c);
        b8.addActionListener(c);
        b7.addActionListener(c);
        b6.addActionListener(c);
        b5.addActionListener(c);
        b4.addActionListener(c);
        b3.addActionListener(c);
        b2.addActionListener(c);
        b1.addActionListener(c);
        b0.addActionListener(c);
        be.addActionListener(c);
        beq.addActionListener(c);
        beq1.addActionListener(c);

        up.add(l);
        d.add(bv);
        d.add(b1);
        d.add(b2);
        d.add(b3);
        d.add(bk);
        d.add(b4);
        d.add(b5);
        d.add(b6);
        d.add(bn);
        d.add(b7);
        d.add(b8);
        d.add(b9);
        d.add(bf);
        d.add(bs);
        d.add(b0);
        d.add(be);
        d.add(beq);
        d.add(bm);
        d.add(beq1);

        f.add(main);
        f.setSize(240, 340);
        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String s = e.getActionCommand();

        if ((s.charAt(0) >= '0' && s.charAt(0) <= '9') || s.charAt(0) == '.') {

            if (!s1.equals(""))
                s2 = s2 + s;
            else
                s0 = s0 + s;

            l.setText(s0 + s1 + s2);
        } else if (s.charAt(0) == 'C') {

            s0 = s1 = s2 = "";

            l.setText(s0 + s1 + s2);
        } else if (s.charAt(0) == '=') {

            double te = 1;

            if (s1.equals("+"))
                te = (Double.parseDouble(s0) + Double.parseDouble(s2));
            else if (s1.equals("-"))
                te = (Double.parseDouble(s0) - Double.parseDouble(s2));
            else if (s1.equals("V2"))
                te = Math.sqrt(Double.parseDouble(s0));
            else if (s1.equals("k2"))
                te = Math.pow(Double.parseDouble(s0), 2);
            else if (s1.equals("kn"))
                te = Math.pow(Double.parseDouble(s0), Double.parseDouble(s2));
            else
                for (int i = 1; i < Double.parseDouble(s0); i++) {
                    te = te * i;
                }

            l.setText(s0 + s1 + s2 + "=" + te);

            s0 = Double.toString(te);

            s1 = s2 = "";
        } else {

            if (s1.equals("") || s2.equals(""))
                s1 = s;

            else {
                double te = 1;

                if (s1.equals("+"))
                    te = (Double.parseDouble(s0) + Double.parseDouble(s2));
                else if (s1.equals("-"))
                    te = (Double.parseDouble(s0) - Double.parseDouble(s2));
                else if (s1.equals("V2"))
                    te = Math.sqrt(Double.parseDouble(s0));
                else if (s1.equals("k2"))
                    te = Math.pow(Double.parseDouble(s0), 2);
                else if (s1.equals("kn"))
                    te = Math.pow(Double.parseDouble(s0), Double.parseDouble(s2));
                else
                    for (int i = 1; i < Double.parseDouble(s0); i++) {
                        te = te * i;
                    }

                s0 = Double.toString(te);

                s1 = s;

                s2 = "";
            }

            l.setText(s0 + s1 + s2);
        }
    }
}