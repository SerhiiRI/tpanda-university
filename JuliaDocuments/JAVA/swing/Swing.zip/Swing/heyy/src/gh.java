public class gh {
    public gh() {
    }
}