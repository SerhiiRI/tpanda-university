import javax.swing.*;

public class messenger {
    private JButton button1;

    public void setData(gh data) {
    }

    public void getData(gh data) {
    }

    public boolean isModified(gh data) {
        return false;
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
