package com.company;

import javax.swing.*;

public class b {
    private JPanel panel1;
}
