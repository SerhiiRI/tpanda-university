package queue;

import java.util.List;

class Node<T> {
    T element;
    Node<T> next;
}

abstract class FIFO<T>{
    Node<T> elements;

    // push function list;
    abstract public boolean push(T element);
    abstract public boolean push(Node<T> element);
    abstract public boolean push(FIFO<T> element);
    abstract public boolean push(T[] element);
    abstract public boolean push(List<T> element);
    // helper functions
    abstract public T pop();
    abstract public void clear();
    abstract public FIFO take (Integer n_element);
    abstract public void debug();
    abstract public int length();
    abstract public List<T> toList();

}