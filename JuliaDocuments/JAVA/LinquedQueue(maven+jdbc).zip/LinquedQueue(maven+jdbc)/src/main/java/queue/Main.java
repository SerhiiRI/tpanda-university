package queue;

public class Main {
    public static void main(String[] args) throws Exception{
        System.out.println("Hello world!");
        JavaToMySQL.JavaSQL();
        DoQueue start = new DoQueue();
        start.doQueue();

    }
}