package queue;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


/**
 * This class represents LinkedList Queue types of <T>
 * @param <T>
 */
public class LinkedListQueue<T> extends FIFO<T> {
    private final int page_size = 3;
    /**
     * ініціалізує вершину стаку, та робить початкову ссилку на null
     */
    public LinkedListQueue() {
        this.elements = null;
    }

    /**
     * Відображає структуру сторінки
     * page_number номер сторінки
     * page_size розмір сторінки (кількість елементів на сторінці)
     * page_elements елемент сторінки типу LinkedListQueue<T>
     * функція debug() для виписування сторінки
     */
    private class Page {
        int page_number;
        int page_size;
        LinkedListQueue<T> page_elements;
        public void debug() {
            System.out.print("(" + this.page_number + "/" + this.page_size + ") ");
            this.page_elements.debug();
        }
    }

    /**
     * Функція для виписування певної сторінки, запитуючи її порядковий номер у користувача
     */
    public void debug_pagginate() {
        ArrayList<Page> pages = new ArrayList<>();
        int fifo_len = this.length();
        int count_page = (fifo_len / page_size) + (fifo_len % page_size > 0 ? 1 : 0);
        for (int number_page = 1; number_page <= count_page; number_page++) {
            pages.add(this.takePage(number_page, fifo_len));
        }

        Scanner scanner = new Scanner(System.in);
        int number_page;
        do{
            System.out.println("Page? [1;" + count_page + "]");
            number_page = scanner.nextInt();
        } while(number_page<=0||number_page>count_page);

        pages.get(number_page-1).debug();
    }


    /**
     * Функція збирає до себе структуру сторінки, ділячи їх на частини розміром page_size
     * start_element вказує на порядковий номер початкового елементу сторінки
     * end_element  вказує на прядковий номер кінцевого елементу сторінки
     * @param number_page number of page
     * @param len length  of this stack
     * @return page
     */
    private Page takePage (int number_page, int len) {
        //Page initializors;
        int end_element=number_page*page_size;
        int start_element= end_element-page_size;

        LinkedListQueue<T> fifo = new LinkedListQueue<T>();
        int i=0;
        Node<T> temp = elements;
        end_element=end_element>len? len: end_element;

        //move queue to start element
        while(temp!=null&&i<start_element){
            temp=temp.next;
            i++;
        }
        //push element to temporary stack
        while (temp != null&&i<end_element&&i>=start_element) {
            Node<T> node = new Node<T>();
            node.element = temp.element;
            fifo.push(node);
            temp = temp.next;
            i++;
        }
        //[3,2,1]->[1,2,3]
        fifo = this.reverse(fifo);
        //set attribute of page
        Page page = new Page();
        page.page_number = number_page;
        page.page_size = page_size;
        page.page_elements=fifo;

        return page;
    }


    /**
     * Pushing to LinkedQueue
     * @param element element of type T to push
     * @return true
     */
    @Override
    public boolean push(T element)
    {
        // створює нову ноду та алокує память
        Node temp = new Node();
        // iніціалізує дані в темпі
        temp.element = element;
        // ставить посилання елементс в наступне
        temp.next = elements;
        // оновлює зверху посилання
        elements = temp;
        return true;
    }


    /**
     * Pushing to LinkedQueue
     * @param element element of type Node to push
     * @return true
     */
    @Override
    public boolean push(Node<T> element) {
        element.next = elements;
        elements = element;
        return true;
    }

    /**
     * Pushing to LinkedQueue
     * @param element element of type FIFO to push
     * @return true
     */
    @Override
    public boolean push(FIFO<T> element) {
        Node<T> temp = element.elements;
        while (temp.next != null) {
            temp = temp.next;
        }
        push(temp);
        this.elements=element.elements;
        return true;
    }

    /**
     * Pushing to LinkedQueue
     * @param element element of type T[] to push
     * @return true
     */
    @Override
    public boolean push(T[] element) {
        for (T i:element) {
            push(i);
        }
        return true;
    }

    /**
     * Pushing to LinkedQueue
     * @param element element of type List<T> to push
     * @return true
     */
    @Override
    public boolean push(List<T> element) {
        for (T i:element) {
            push(i);
        }
        return true;
    }

    /**
     * Pop element from LinkedQueue (without param)
     * @return temp.element
     */
    @Override
    public T pop()
    {
        if (elements == null) {
            System.out.print("\nStack Underflow");
        }
        Node<T> temp = elements;
        elements = (elements).next;
        return temp.element;
    }

    /**
     * Clear LinkedQueue
     */
    @Override
    public void clear() {
        elements=null;
    }

    /**
     * Take first N elements from LinkedQueue
     * @param n_element count of elements to return
     * @return fifo
     */
    @Override
    public LinkedListQueue<T> take (Integer n_element) {
        LinkedListQueue<T> fifo = new LinkedListQueue<T>();
        Node<T> temp = elements;
        int i=0;
        while (temp != null&&i<n_element) {
            Node<T> node = new Node<T>();
            node.element = temp.element;
            fifo.push(node);
            temp = temp.next;
            i++;
        }
        fifo = this.reverse(fifo);
        return fifo;
    }

    /**
     * Reverse elements from LinkedList([3,2,1] -> [1,2,3])
     * @return new_fifo clone of original fifo
     */
    public LinkedListQueue<T> reverse (LinkedListQueue<T> fifo){
        LinkedListQueue<T> new_fifo = new LinkedListQueue<T>();
        Node<T> temp = fifo.elements;
        while (temp!=null){
            Node<T> node = new Node<T>();
            node.element=temp.element;
            new_fifo.push(node);
            temp=temp.next;
        }
        return new_fifo;
    }

    /**
     * Printing elements to terminal
     */
    @Override
    public void debug() {
        if (elements == null) {
            System.out.print("\nStack is empty");
        }
        else {
            Node<T> temp = elements;
            while (temp != null) {
                System.out.printf(temp.next==null?"%s":"%s->", temp.element.toString());
                temp = temp.next;
            }
            System.out.println();
        }
    }

    /**
     * Length of LinkedQueue
     * @return i length of LinkedQueue
     */
    @Override
    public int length() {
        int i=0;
        Node<T> temp = elements;
        while (temp!=null){
            temp=temp.next;
            i++;
        }
        return i;
    }


    /**
     * Convert List<T> to List
     * @return list
     */
    @Override
    public List<T> toList() {
        List<T> list = new ArrayList<T>();
        Node<T> temp = elements;
        int i=0;
        while (temp.next != null) {
            list.add(temp.element);
            temp=temp.next;
            i++;
        }
        list.toArray();
        return list;
    }
}

