package queue;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class JavaToMySQL {

    // JDBC variables for opening and managing connection
    private static Connection con;
    private static Statement stmt;
    private static ResultSet rs;
    public static LinkedListQueue<String> colours = new LinkedListQueue<>();
    public static LinkedListQueue<Integer> digits = new LinkedListQueue<>();


    public static void JavaSQL() throws ClassNotFoundException {
        String query = "select * from data";

        try {

            con = DriverManager.getConnection("jdbc:mysql://localhost/test?allowPublicKeyRetrieval=true&useSSL=false", "root", "NewPass4!");

            stmt = con.createStatement();

            rs = stmt.executeQuery(query);

            while (rs.next()) {
                digits.push(rs.getInt(1));
                colours.push(rs.getString(2));
            }
            digits.debug();
            colours.debug();

        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        } finally {
            //close connection ,stmt and resultset here
            try { con.close(); } catch(SQLException se) { /*can't do anything */ }
            try { stmt.close(); } catch(SQLException se) { /*can't do anything */ }
            try { rs.close(); } catch(SQLException se) { /*can't do anything */ }
        }
    }
}
