package queue;


public class DoQueue {
    public void doQueue() {

    }
}